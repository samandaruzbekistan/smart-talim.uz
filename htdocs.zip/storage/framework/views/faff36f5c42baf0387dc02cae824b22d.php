<?php $__env->startSection('course'); ?>class="active"<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <main class="main">

        <!-- Page Title -->
        <div class="page-title" data-aos="fade">
            <div class="heading">
                <div class="container">
                    <div class="row d-flex justify-content-center text-center">
                        <div class="col-lg-8">
                            <h1>Internet axborot rerurslari</h1>
                        </div>
                    </div>
                </div>
            </div>
            <nav class="breadcrumbs">
                <div class="container">
                    <ol>
                        <li><a href="<?php echo e(route('home')); ?>">Bosh sahifa</a></li>
                        <li class="current">Internet</li>
                    </ol>
                </div>
            </nav>
        </div><!-- End Page Title -->

        <!-- Courses Course Details Section -->
        <section id="courses-course-details" class="courses-course-details section">

            <div class="container" data-aos="fade-up">

                <div class="row">
                    <div class="col-lg-8">
                        <p class="mt-3">
                           <b> WWW.UZ Milliy axborot-qidiruv tizimi.</b> WWW.UZ – bu barcha foydalanuvchilar uchun yurtimizning Intеrnеt tarmogʻidagi milliy sеgmеnti axborotlaridan qulay tarzda foydalanish imkoniyatini bеruvchi tizimdir. Milliy axborot-qidiruv tizimini rivojlantirish ishlari axborot va kompyutеr tеxnologiyalarini rivojlantirish va joriy etish UZINFOCOM Markazi tomonidan olib boriladi. Milliy axborot-qidiruv tizimining asosiy hususiyatlaridan biri uning koʻp tilli axborot qidiruvi (ruscha, oʻzbеkcha) va boshqa milliy axborot tizimlari va ma’lumot omborlari bilan oʻzaro ishlay olishidadir.WWW.UZ Intеrnеt tarmogʻi foydalanuvchilariga milliy sigmеntda joylashgan vеb-saytlar boʻyicha qidiruv xizmatini taqdim etadi va qidiruvni vеb-sayt manzili va ichki ma’lumoti boʻyicha olib borishi mumkin. Bu esa foydalanuvchiga kеrakli boʻlgan axborotni samarali qidirish va topish imkoniyatini bеradi. Bundan tashqari Shu WWW.UZ qidiruv tizimi Intеrnеt rеsurslari (vеb-saytlari) katalogini va vеb-saytlar rеytingi yuritadi, saytlar boʻyicha jamlangan statistik ma’lumotni toʻplaydi hamda axborot tеxnologiyaari sohasidagi yangiliklar va maqolalarni yoritib boradi. WWW.UZ “Katalog” boʻlimi – Intеrnеt tarmogʻida ochiq holda joylashgan, Oʻzbеkiston Rеspublikasiga aloqador boʻlgan, roʻyxatga olingan, izohlari kеltirilgan va katalog mavzulari boʻyicha saralangan vеb-saytlar toʻplami. WWW.UZ katalogi foydalanuvchilari oʻzlariga kеrak boʻlgan saytni mavzular boʻyicha (Iqtisod, OAV, Madaniyat va boshqalar) qidirish orqali tеzroq topishlari mumkin. Katalog har kuni qidiruv tizimining faol foydalanuvchilari tomonidan yangi saytlar bilan boyitib boriladi. Shu bilan birga WWW.UZning har bir foydalanuvchisi “Top-rеyting”  boʻlimiga kirib, barcha roʻyxatga olingan saytlar rеytingini koʻrishi, “Jamlangan statistika” boʻlimida esa ularning statistikasi bilan tanishib chiqishi mumkin.
                        </p>

                        <p>
                            <b>Butunjahon tarmogʻi.</b> Internetdagi yuz millionlab veb-serverlar boʻlib, ular gipermatnli texnologiyalardan foydalanadigan yuzlab milliard veb-sahifalarni oʻz ichiga oladi.Veb-sahifa boʻlishi mumkin multimedia, ya’ni tarkibida turli xil <b>multimedia</b> obʻektlari boʻlishi mumkin: grafikalar, animatsiya, ovoz va video
                        </p>

                        <p>
                            Veb-sahifa boʻlishi mumkin <b>interfaol</b>, ya’ni bepul elektron pochta foydalanuvchilarini roʻyxatdan oʻtkazishda, Internet-doʻkonlarda xarid qilishda va hokazolarda ishlatiladigan maydonlarga ega shakllarni oʻz ichiga oladi.
                            Tematik jihatdan bogʻliq boʻlgan veb-sahifalar odatda shaklda boʻladi <b>Veb-sayt,</b> ya’ni havolalar orqali bir butunga bogʻlangan hujjatlarning ajralmas tizimi.

                        </p>

                        <p>
                            <b>Veb-sahifaning manzili.</b> Hozirda Internetning veb-serverlarida koʻplab veb-sahifalar joylashtirilgan. Veb-sahifa manzilidan foydalanib Internetda veb-sahifani topishingiz mumkin.Veb-sahifaning manzili hujjatga kirish usuli va hujjat joylashtirilgan Internet-server nomini oʻz ichiga oladi.Hyper Text Transfer Protocol (HTTP) veb-sahifalarga kirish usuli sifatida ishlatiladi. Protokolni yozishda uning nomidan keyin ikki nuqta va ikkita kesma yoziladi: http://. Misol tariqasida, Ziyonet axborot ta’lim portali-saytining sarlavha sahifasini yozamiz. Sahifa ziyonet.uz serverida joylashgan, shuning uchun manzil quyidagi shaklga ega:http://ziyonet.uz
                        </p>

                        <p>
                            <b>Brauzerlar.</b> Veb-sahifalarni koʻrib chiqish maxsus tomoshabinlar - brauzerlar yordamida amalga oshiriladi. Hozirda Internet Explorer, Mozilla va Opera brauzerlari eng keng tarqalgan.Brauzer oynasi dastur oynasining standart elementlarini oʻz ichiga oladi:
                            - buyruqlar toʻplamini oʻz ichiga olgan oyna menyusi Fayl, tahrirlash, koʻrish, sevimlilar, xizmat va ma’lumotnoma;
                            - tugmachalari bitta veb-sahifadan boshqasiga oʻtishga imkon beradigan asboblar paneli (tugmalar) Oldinga, orqaga, uyga), shuningdek ularni yuklash jarayonini boshqarish (tugmalar) Toʻxtang, yangilang);
                            - matn maydoni Manzil:, kerakli veb-sahifaning Internet manzili klaviaturadan kiritiladi yoki roʻyxatdan tanlanadi;
                            - web-sahifalar koʻriladigan ish maydoni.

                        </p>
                        <img src="https://deviceatlas.com/sites/deviceatlas.com/files/images/play-store-browsers-min-min.png" class="img-fluid" alt=""><br>

                        <p class="mt-4">
                            <b>Giperbogʻlanish</b> gipermatn texnologiyasining asosi. WWW sahifasida ma’lumot gipermatnli hujjatlar shaklida olinadi.Gipermatn boshqa matnli hujjatlarga yoʻl koʻrsatuvchi matndir. Bu esa boshqa matnlarga (bu matnlar qaysi mamlakatning serverida turishidan qatʻiy nazar) tezda oʻtish va yuklanish imkonini beradi. Odatda  ixtiyoriy  matn  simvollarning  uzun  bir  qatordan  iborat  boʻlib, u bir yoʻnalishda  oʻqiladi.
                            Gipermatn texnologiyasi matnni koʻp oʻlchamli  shaklda tasvirlashdan iborat, ya’ni tarmoq tipidagi iyerarxik tuzilmadir. Matn  koʻrinishdagi  material  boʻlaklarga (parchalarga) boʻlinadi. Kompyuter ekranida koʻrinadigan matinning har bir boʻlagi boshqa boʻlaklar bilan koʻp sonli bogʻlanishlar orqali bogʻlangan boʻlib,u oʻrganilayotgan obʻekt haqidagi axborotni aniqlashtirish imkoniyatini beradi va tanlangan bogʻlanishlar boʻyicha bir yoki bir necha yoʻnalishda harakat qiladi. Gipermatn boʻlaklarga boʻlingan materialni nochiziq tarmoq shaklda tashkil qilishga ega boʻlib, ularning har biri uchun bogʻlanishlarning ma’lum turi boʻyicha boshqa boʻlaklarga oʻtishlar koʻrsatilgan. Bogʻlanishlarni (aloqalarni) oʻrnatishda turli asoslarga (kalitlarga) tayanish mumkin, ammo har qanday holda gap faqat bogʻlanayogan boʻlaklar maʻnosining, semantikasining yaqinligi haqida boradi. Koʻrsatilgan  bogʻlanishlar izidan borib, materialni oʻqish yoki oʻzlashtirish tartibi yagona emas, balki ixtiyoriy tartibda boʻlishi mumkin. Matn oʻzining yopiqligini yoʻqotib, prinsipial ochiq holda boʻlad.i Gipermatnga uning boʻlaklari uchun mavjud bogʻlanishlarni koʻrsatib yangi boʻlaklarni qoʻyish mumkin. Matnning strukturasi buzulmaydi, chunki gipertekstning aprior berilgan strukturasi umuman yoʻq.Shunday  qilib, gipermatn –bu strukturalashtirilmay erkin jamlangan bilimlarni taqdim qilishning yangi texnologiyasi. U shu bilan axborotlarni taqdim etishning (tavirlashning) boshqa modellaridan farq qiladi.

                        </p>



                    </div>

                    <div class="col-lg-4">
                        <h3>Mavzular:</h3>
                        <a href="<?php echo e(route('internet.1')); ?>">
                            <div class="course-info d-flex justify-content-between align-items-center">
                                <h5 ><i class="bi bi-play-circle text-success"></i> Internet tarmogʻi</h5>
                            </div>
                        </a>
                        <a href="<?php echo e(route('internet.2')); ?>">
                            <div class="course-info d-flex justify-content-between align-items-center">
                                <h5><i class="bi bi-play-circle text-success"></i> Web-sahifa va uning tuzilishi</h5>
                            </div>
                        </a>
                        <a href="<?php echo e(route('internet.3')); ?>">
                            <div class="course-info d-flex justify-content-between align-items-center">
                                <h5 ><i class="bi bi-play-circle text-success"></i> Internet tarmogʻi qidiruv tizimlari</h5>
                            </div>
                        </a>
                        <a href="<?php echo e(route('internet.4')); ?>">
                            <div class="course-info d-flex justify-content-between align-items-center">
                                <h5 class="text-success"><i class="bi bi-play-circle text-success"></i> Internet axborot rerurslari</h5>
                            </div>
                        </a>
                        <a href="<?php echo e(route('internet.5')); ?>">
                            <div class="course-info d-flex justify-content-between align-items-center">
                                <h5><i class="bi bi-play-circle text-success"></i> Internet xizmatlari</h5>
                            </div>
                        </a>
                        <a href="<?php echo e(route('internet.6')); ?>">
                            <div class="course-info d-flex justify-content-between align-items-center">
                                <h5><i class="bi bi-play-circle text-success"></i> Elektron pochta xizmati</h5>
                            </div>
                        </a>
                    </div>
                </div>

            </div>

        </section>


    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.header_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\smart-study\resources\views/user/internet/themes/4.blade.php ENDPATH**/ ?>