<?php $__env->startSection('course'); ?>class="active"<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>

    <main class="main">

        <!-- Page Title -->
        <div class="page-title" data-aos="fade">
            <div class="heading">
                <div class="container">
                    <div class="row d-flex justify-content-center text-center">
                        <div class="col-lg-8">
                            <h1>Dasturiy ta’minot</h1>
                        </div>
                    </div>
                </div>
            </div>
            <nav class="breadcrumbs">
                <div class="container">
                    <ol>
                        <li><a href="<?php echo e(route('home')); ?>">Bosh sahifa</a></li>
                        <li class="current">Operatsion tizimlar</li>
                    </ol>
                </div>
            </nav>
        </div><!-- End Page Title -->

        <!-- Courses Course Details Section -->
        <section id="courses-course-details" class="courses-course-details section">

            <div class="container" data-aos="fade-up">

                <div class="row">
                    <div class="col-lg-8">
                        <p>
                            <b>Dasturiy ta’minot</b> – har bir foydalanuvchining manfaatlarini koʻzlab, kompyuterlardan foydalanishni taʻminlaydigan barcha dasturlar va tegishli hujjatlar toʻplami.Tizim va amaliy dasturlarni farqlang. Dasturiy ta’minot quyidagicha ifodalanishi mumkin:
                        </p>

                        <p>
                            <b>Tizim dasturiy ta’minot.</b> Kompyuterning ishlashini taʻminlaydigan dasturlar toʻplami. Tizim dasturiy ta’minoti quyidagilarga boʻlinadi: asosiy va xizmat.Tizim dasturlari hisoblash tizimining ishlashini boshqarish, turli yordamchi funktsiyalarni (nusxa koʻchirish, sertifikatlar berish, test qilish, formatlash va boshqalar) bajarish uchun moʻljallangan. Asosiy dasturiy ta’minot oʻz ichiga oladi: OS; qobiq; tarmoq operatsion tizimlari.
                        </p>

                        <p>
                            <b>Xizmat dasturiy ta’minot.</b> Dasturlarni (utilitalarni) oʻz ichiga oladi: diagnostika; antivirus; tashuvchilarga xizmat koʻrsatish;arxivlash; tarmoqqa texnik xizmat koʻrsatish.
                        </p>

                        <p>
                            <b>Amaliy dasturiy ta’minot.</b> Muayyan fan sohasining ma’lum bir sinfi muammolarini hal qilish uchun dasturlar majmuasi. Amaliy dasturiy ta’minot faqat tizim dasturiy ta’minoti bilan ishlaydi. Amaliy dasturlarga amaliy dasturlar deyiladi.
                        </p>

                        <b>Ularga quyidagilar kiradi:</b><br>
                        -	Matn protsessorlari; <br>
                        -	Jadvalli protsessorlar;<br>
                        -	Ma’lumot bazasi;<br>
                        -	Integratsiyalashgan paketlar;<br>
                        -	Illyustrativ va biznes grafik tizimlari (grafik protsessorlar);<br>
                        -	Ekspert tizimlari;<br>
                        -	Oʻquv dasturlari;<br>
                        -	Matematik hisoblar, modellashtirish va tahlil qilish dasturlari;<br>
                        -	Aloqa dasturlari.<br>
                        <br>
                        <p>
                            <b>Dasturlash tizimlari.</b> Bu yangi dasturiy mahsulotlarni ishlab chiqish, disk raskadrovka va joriy etish uchun dasturlar toʻplamidir. Dasturlash tizimlari odatda quyidagilarni oʻz ichiga oladi:
                        </p>
                        -	Tarjimonlar;<br>
                        -	Dasturiy ta’minotni ishlab chiqish muhiti;<br>
                        -	Mos yozuvlar dasturlari kutubxonalari (funksiyalar, protseduralar);<br>
                        -	Tuzatuvchilar;<br>
                        -	Havola muharrirlari va boshqalar.<br>

                    </div>

                    <div class="col-lg-4">
                        <h3>Mavzular:</h3>
                        <a href="<?php echo e(route('operating.1')); ?>">
                            <div class="course-info d-flex justify-content-between align-items-center">
                                <h5><i class="bi bi-play-circle text-success"></i> Umumiy operatsion tizimlar</h5>
                            </div>
                        </a>
                        <a href="<?php echo e(route('operating.2')); ?>">
                            <div class="course-info d-flex justify-content-between align-items-center">
                                <h5><i class="bi bi-play-circle text-success"></i> Kompyuter va mobil qurilmalar operatsion tizimlari</h5>
                            </div>
                        </a>
                        <a href="<?php echo e(route('operating.3')); ?>">
                            <div class="course-info d-flex justify-content-between align-items-center">
                                <h5><i class="bi bi-play-circle text-success"></i> Xizmat koʻrsatuvchi dasturlar</h5>
                            </div>
                        </a>
                        <a href="<?php echo e(route('operating.4')); ?>">
                            <div class="course-info d-flex justify-content-between align-items-center">
                                <h5 class="text-success"><i class="bi bi-play-circle text-success"></i> Dasturiy ta’minot</h5>
                            </div>
                        </a>

                        <a href="<?php echo e(route('operating.5')); ?>">
                            <div class="course-info d-flex justify-content-between align-items-center">
                                <h5><i class="bi bi-play-circle text-success"></i> Ta’lim tizimida axborot madaniyatining ahamiyati</h5>
                            </div>
                        </a>
                    </div>
                </div>

            </div>

        </section>


    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.header_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\smart-study\resources\views/user/operating_systems/themes/4.blade.php ENDPATH**/ ?>