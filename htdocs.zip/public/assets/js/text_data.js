let btn1 = "Axborotdan foydalanish imkoniyati va samaradorligi uning reprezentativligi, mazmundorligi, yetarliligi, aktualligi, oʻz vaqtidaligi, aniqligi, ochiqligi, ishonarliligi, barqarorligi kabi asosiy  isteʻmol sifat koʻrsatkichlari bilan bogʻliqdir. Ularni batafsil koʻrib chiqamiz"
let btn2 = "Obyekt xususiyatini adekvat ifoda etish maqsadida axborotni toʻgʻri tanlash va shakllantirish bilan bogʻliqdir"
let btn3 = "Semantik hajmini ifoda etadi. Axborot mazmundorligi ortishi bilan axborot tizimining semantik oʻtkazish quvvati ortadi, chunki bir xildagi ma’lumotni olish uchun kamroq hajmda ma’lumotni oʻzgartirish talab etiladi"
let btn4 = "Qaror qabul qilish uchun minimal, lekin yetarli tarkibga ega ekanligini bildiradi. Axborotning toʻlaligi tushunchasi uning maʻnosi mazmuni (semantikasi) va pragmatikasi bilan bogʻliqdir. Toʻgʻri qaror qabul qilish uchun yetarli boʻlmagan, xuddi shuningdek ortiqcha boʻlgan axborot ham foydalanuvchining qaror qabul qilish samaradorligini kamaytiradi"
let btn5 = "Axborotdan foydalanish vaqtida uning  boshqarish uchun qimmatliligi saqlanib qolishi bilan belgilanadi va uning xususiyatlari oʻzgarish dinamikasiga hamda ushbu axborot paydo boʻlgan vaqtdan buyon oʻtgan davr oraligʻiga bogʻliq boʻladi."
let btn6 = "Axborotning avvaldan belgilab qoʻyilgan vazifani hal etish vaqti bilan kelishilgan vaqtdan kechikmasdan olinganligini bildiradi"
let btn7 = "Olinayotgan axborotning obyekt, jarayon, hodisa va hokazolarning aniq holatiga yaqinligi darajasi bilan belgilanadi"
let btn8 = "Foydalanuvchi axborotni idroklashi uchun uni olish va oʻzgartirish jarayonlarini bajarish yoʻllari bilan amalga oshiradi. Misol uchun, axborot tizimida axborot foydalanuvchini oʻzgartirishi uchun ochiq va qulay shaklga aylantirib beriladi. Bu axborotning semantik shakli va foydalanuvchining tezaurusini moslashtirish yoʻli bilan amalga oshiriladi"
let btn9 = "Axborotning obyektlarini kerakli aniqlikda aks ettirish xususiyati bilan belgilanadi. Axborot ishonarliligi zarur aniqlikda ehtimollar nazariyasi bilan oʻlchanadi, yaoni axborot aks ettirgan koʻrsatkich uning haqiqiy qiymatidan kerakli aniqlikda boʻlish ehtimolini bildiradi"
let btn10 = "Axborotning asos qilib olingan ma’lumot aniqligini buzmasdan oʻzgarishlarga taosir qilishga qodirligini aks ettiradi. Axborotning barqarorligi aynan reprezentativlik axborotni tanlash va shakllantirishning tanlab olingan uslubiyotiga bogʻliqdir"
let btn11 = "Axborotni oʻlchash uchun ikki koʻrsatkich kiritilgan: axborot miqdori I va qiymatlar hajmi V. Bu koʻrsatkichlar axborot adekvatlik shakllarida turli ifoda va talqinga ega. Har bir shakl oʻziga hos axborot miqdoriga va qiymatlar hajmiga ega"
let btn12 = "Bu axborotning oʻlchov birligi foydalanuvchi qoʻygan maqsadni egallash uchun kerak boʻlgan axborotning yaroqliligi bilan ifodalanadi. Paragmatik oʻlchov ham  nisbiy boʻlib, tizimda u axborotni qaysi tizimda ishlatishga bogʻliqdir"

let data_json = {
    "btn1" : btn1,
    "btn2" : btn2,
    "btn3" : btn3,
    "btn4" : btn4,
    "btn5" : btn5,
    "btn6" : btn6,
    "btn7" : btn7,
    "btn8" : btn8,
    "btn9" : btn9,
    "btn10" : btn10,
    "btn11" : btn11,
    "btn12" : btn12,
}
